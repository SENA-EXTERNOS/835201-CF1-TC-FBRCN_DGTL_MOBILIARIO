function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6V9N2KOHL2S":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

